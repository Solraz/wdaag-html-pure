const navbar = () => {
	let nav = document.querySelector(`nav`);
};

export { navbar };
