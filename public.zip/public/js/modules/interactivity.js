// const sticky_text = () => {
// 	let stickies = document.querySelectorAll(`.sticky`);

// 	for (const s of stickies) {
// 		let sticky = s.getBoundingClientRect();
// 		let sticky_parent = s.parentElement.getBoundingClientRect();
// 		console.log(sticky, sticky_parent);

// 		window.addEventListener("scroll", (e) => {
// 			let position = window.scrollY;
// 		});
// 	}
// };

// export { sticky_text };
